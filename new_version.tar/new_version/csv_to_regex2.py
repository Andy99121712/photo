import csv
import re
import os 

def get_filelist(csvpath):
    filenames = os.listdir(csvpath)
    #print(cwd+txtpath)
    csv_files = []
    for filename in filenames:
        if ".csv" in filename:
                csv_files.append(filename)
    return csv_files

def write_file():
    # regex_file
    with open(store_path+'sform_regex.csv','a') as regex_file:
        regex_file.write(str(file_name[1].split('.csv')[0])+','+str(regex_pattern)+'\n')
    #field_list file
    with open(store_path+'sform_list.csv','a') as fieldlist_file:
        fieldlist_file.write(str(file_name[1].split('.csv')[0])+','+str(field_list)+'\n')

def check_exist():
    transcation_code = str(file_name[1].split('.csv')[0])
    if os.path.exists(store_path+'sform_regex.csv') and os.path.exists(store_path+'sform_regex.csv'):
        with open(store_path+'sform_regex.csv') as csv_file:
            csv_reader = csv.reader(csv_file)
            for row in csv_reader:
                if row[0]==transcation_code:
                    print('sform already transfer')
                    flag = True
                    break
                else:
                    flag = False
            if flag!= True:
                write_file()
    else :
        print('file not exist. Creating.....')
        write_file()

 
csvpath='/etc/logstash/global/csv/' #need to modify
file_list = get_filelist(csvpath)
for file_name in file_list:
    print('now:'+file_name)
    csv_file = open(csvpath+file_name,'r')
    csv_reader = csv.reader(csv_file)
    unsorting_list =[]
    dict_count =1
    field_dict = {}
    for row in csv_reader:
        # format error 
        if len(row)<7 or len(row)>9 :
            print('SFORM FORMAT ERROR ,PLZ CHECK'+file_name)
            break
        # row[5] not define
        if row[5]== '' and row[5].isdigit()==False:
            print("start_postition not found")
            break
        #append row
        unsorting_list.append(row)
        original_list = unsorting_list
        field_dict[row[0]] = dict_count
        dict_count+=1
	
    #sorting    
    for j in range(len(unsorting_list)):
        for k in range(0,len(unsorting_list)-j-1):
            if unsorting_list[k][5]>unsorting_list[k+1][5]:
                unsorting_list[k],unsorting_list[k+1]=unsorting_list[k+1],unsorting_list[k]
    sorting_list = unsorting_list
    #print('after sorting:',sorting_list)
    field_list = ''
    regex_pattern = ''
    field_counter =0
    now_position = 0
    for i in range(len(sorting_list)):
        if sorting_list[i][6]!= '':
            # check field length
            field_counter+=1
            start_position = int(sorting_list[i][5])-1
            if re.search(r'([X9])\((\d+)\)', sorting_list[i][6]):
                sform_len = re.search(r'(\d+)(?=\))',sorting_list[i][6])[1]
            else:
                sform_len = len(sorting_list[i][6])
            #check data type
            if 'X' in sorting_list[i][6]: # check data type
                is_string = True
                if field_dict.get(sorting_list[i][0])<10:
                    field_name = 'field'+'0'+str(field_dict.get(sorting_list[i][0]))
                else:
                    field_name = 'field'+str(field_dict.get(sorting_list[i][0]))
            else:
                is_string = False
                if field_dict.get(sorting_list[i][0])<10:
                    field_name = 'field'+'0'+str(field_dict.get(sorting_list[i][0]))
                else:
                    field_name = 'field'+str(field_dict.get(sorting_list[i][0]))
            if now_position == start_position:
                regex_pattern+='(?<'+field_name +'>.{'+ str(sform_len) + '})'
            else:
                regex_pattern+= '(?<tmp>.{'+str(start_position-now_position)+'})'+'(?<'+field_name +'>.{'+ str(sform_len) + '})'
            #print(regex_pattern)
            now_position = start_position+int(sform_len)

            # check floating or not
            if 'V' in sorting_list[i][6]:
                if re.search(r'(?<=[V])[9]+', sorting_list[i][6]):      # if pattern like V999
                    after_point = re.search(r'(?<=[V])[9]+', sorting_list[i][6])
                    after_point_number = len(after_point[0])
                else:                                          # if pattern like V9(19)
                    after_point = re.search(r'(?<=[V][9]\().*?(?=\))|(?<=[V]\().*?(?=\))', sorting_list[i][6])
                    #print(sorting_list[i][6])
                    #print(type(after_point),after_point[0])
                    after_point_number =int(after_point[0])
                regex_pattern+='(?<'+field_name+'_after_point>.{'+ str(after_point_number) + '})'
                now_position+=after_point_number

            # check symbol or not
            if 'S' in sorting_list[i][6]:
                is_symbol = True
                regex_pattern+='(?<'+field_name+'_symbol>.{1})'
                now_position+=1

                #field and field name
            field_list+='tel_'+field_name +':'+original_list[i][0]+'|'    
        else:
            print('TRASLATE ERROR!'+file_name)
    file_name = file_name.split('scr')
    store_path = '/root/Rick/taishin/taibee2.0/new_test/'      #'/etc/logstash/global/' #need to modify
    check_exist()
