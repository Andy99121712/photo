csv_to_regex2.py:
- line 41 path -->  csv path 
- line 129 path --> store path

taibee.conf
- line 59 path --> dictionary path 
- line 65 path --> dictionary path 
